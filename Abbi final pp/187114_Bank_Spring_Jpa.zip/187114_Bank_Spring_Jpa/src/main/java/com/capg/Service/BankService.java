package com.capg.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.Bean.Account;
import com.capg.Bean.Address;
import com.capg.DAO.BankDao1;





class MyException extends Exception {
	String s1;

	MyException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

}
@Service("BankService")
public class BankService implements BankService1 {
	@Autowired
	private BankDao1 bd;
	
	
	public boolean checkName(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new MyException("Invalid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}

		}
		return false;

	}

	public long getBalance(long accNo) {
		long acc = bd.getBalance(accNo);
		return acc;

	}

	public String getTransaction(long accNo) {
		String str = bd.getTransaction(accNo);
		return str;

	}

	public void setBalance(long accNo, long bal, String st)  {
		bd.setBalance(accNo, bal, st);

	}

	public String addAccount(String name, long mobile,  String password,int i,Address add)
			 {
		Account bb=new Account();
	
			bb.setName(name);
			bb.setMobile(mobile);
			bb.setPassword(password);
			bb.setAddress(add);
		
			bb.setBalance(1000);
			bb.setTran("\n    TransID : "+i+"       Amount Deposited Rs.1000");
			long accNo=bd.setData(bb);
			return " Account Created Successfully \n Your Account number is " + accNo;
			 }

	public boolean checkAccNo(long acc) {
		try {
			if (bd.checkAccNo(acc)) {

				return true;
			}

			else
				throw new MyException("Wrong Account Number");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	public boolean checkPass(String st,long accNo) {
		try {
			if (bd.checkPassword(st,accNo)) {

				return true;
			} else
				throw new MyException("Wrong Password");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	public boolean checkM(long mob) {
		// TODO Auto-generated method stub
		String s = Long.toString(mob);
		int n = s.length();
		try {
			if (n == 10) {
				return true;
			} else {
				throw new MyException("Invalid Number");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	public boolean checkP(String password) {
		// TODO Auto-generated method stub
		try {
			if (password.length() >= 6) {
				return true;
			} else {
				throw new MyException("Invalid Password \n Enter more than six characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}
	
}
