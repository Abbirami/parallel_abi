package com.capg.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.Bean.Account;






@Repository("BankDao")
public class BankDao implements BankDao1 {

	@PersistenceContext(name = "persistcon")
	private EntityManager emg;

	@Transactional
	public long getBalance(long accNo) {
		
		Account emp1 = (Account) emg.find(Account.class, new Long(accNo));
		
		return emp1.getBalance();
	}

	@Transactional
	public void setBalance(long accNo, long bal, String st) {

		Account emp1 = (Account) emg.find(Account.class, new Long(accNo));
		String str = emp1.getTran() + st;
		emp1.setTran(str);
		emp1.setBalance(bal);
		emg.merge(emp1);
	}

	@Transactional
	public boolean checkPassword(String str, long accNo) {


		Account emp1 = (Account) emg.find(Account.class, new Long(accNo));
		if (emp1.getPassword().equals(str))
			return true;
		else
			return false;

	}

	@Transactional
	public boolean checkAccNo(long accNo) {

		Account emp1 = (Account) emg.find(Account.class, new Long(accNo));

		if (emp1 == null)
			return false;
		else
			return true;

	}

	@Transactional
	public long setData(Account bb) {
		emg.persist(bb);
		return bb.getAccNo();
	}

	@Transactional
	public String getTransaction(long accNo) {
		// TODO Auto-generated method stub

		Account emp1 = (Account) emg.find(Account.class, new Long(accNo));

		return emp1.getTran();
	}
	
	
	
}
