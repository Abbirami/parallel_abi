package com.cg.restdemo.exception;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception{
	public AccountNotFoundException() {
		super();
	}

	public AccountNotFoundException(String msg) {
		super(msg);
	}
}
