package com.cg.restdemo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.restdemo.entities.CustomerDetails;
import com.cg.restdemo.entities.TransactionDetails;
import com.cg.restdemo.exception.AccountNotFoundException;
import com.cg.restdemo.service.IService;


@RestController
@RequestMapping("/xyz")
public class CustomerController {
	@Autowired
	IService service;

	@PostMapping("/create")
	public CustomerDetails createAccount(@Valid @RequestBody CustomerDetails customerDetails) throws AccountNotFoundException {
		return service.createAccount(customerDetails);
	}

	@GetMapping("/showDetails/{accNo}")
	public CustomerDetails accountsDetails(@PathVariable Long accNo) throws AccountNotFoundException {
		return service.accountsDetails(accNo);
	}

	@GetMapping("/showBalance/{accNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNo) throws AccountNotFoundException {
		Double balance = service.showBalance(accNo);
		return new ResponseEntity<String>("Available balance: " + balance, HttpStatus.OK);
	}

	@PutMapping("/deposit/{accNo}/{amt}")
	public ResponseEntity<String> deposit(@Valid @PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		Double balance = service.deposit(accNo, amt);
		return new ResponseEntity<String>("After deposited: " + balance, HttpStatus.OK);
	}

	@PutMapping("/withdraw/{accNo}/{amt}")
	public ResponseEntity<String> withdraw(@Valid @PathVariable Long accNo, @PathVariable Double amt) throws AccountNotFoundException {
		Double balance = service.withdraw(accNo, amt);
		return new ResponseEntity<String>("After withdrawn: " + balance, HttpStatus.OK);
	}

	@PutMapping("/fundTransfer/{accNo}/{amount}/{accNo1}")
	public ResponseEntity<String> fundTransfer(@Valid @PathVariable Long accNo, @PathVariable Double amount,
			@PathVariable Long accNo1) throws AccountNotFoundException {
		Double balance = service.fundTransfer(accNo, amount, accNo1);
		return new ResponseEntity<String>("Transaction Completed\n*****************************"
				+ "\nAmount transferred: "+amount
				+ "\nDeposited account number: "+accNo1+"\n*****************************\n"
				+ "After transaction: " +balance
				+ "\n*****************************", HttpStatus.OK);
	}

	@GetMapping("/print/{accNo}")
	public List<TransactionDetails> printTransaction(@PathVariable Long accNo) {
		return service.printTransaction(accNo);
	}

}
