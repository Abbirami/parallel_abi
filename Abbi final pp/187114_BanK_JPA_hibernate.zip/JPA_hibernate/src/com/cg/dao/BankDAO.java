package com.cg.dao;




import javax.persistence.EntityManager;

import com.cg.entity.Account;


public class BankDAO implements BankDAOI {

	EntityManager em;
	DataBase db=new DataBase();
	
	
	
	@Override
	public long getBalance(long accNo) {
		
		em = db.getConnection();
		em.getTransaction().begin();
		Account caa=(Account) em.find(Account.class,new Long(accNo));
		em.getTransaction().commit();
		return caa.getBalance();
		

	}

	@Override
	public void setBalance(long accNo, long bal, String st){
		em = db.getConnection();
		em.getTransaction().begin();
		Account caa=(Account) em.find(Account.class,new Long(accNo));
		
		
	
		String str = caa.getTran() + st;
		caa.setTran(str);
		caa.setBalance(bal);
		em.merge(caa);
				em.getTransaction().commit();
	}

	
	@Override
	public boolean checkPassword(String str,long accNo)  {
		em = db.getConnection();
		em.getTransaction().begin();
		Account caa=(Account) em.find(Account.class,new Long(accNo));
		if (caa.getPassword().equals(str))
			return true;
		else
			return false;

	}

	@Override
	public boolean checkAccNo(long accNo){
		em = db.getConnection();
		em.getTransaction().begin();
	Account caa=(Account) em.find(Account.class,new Long(accNo));
		
		if (caa==null)
			return false;
		else
			return true;

	}

	@Override
	public long setData(Account bb) {
	
		em = db.getConnection();
		em.getTransaction().begin();

		em.persist(bb);
		em.getTransaction().commit();
		return bb.getAccNo();
	}

	@Override
	public String getTransaction(long accNo) {
		// TODO Auto-generated method stub
		em = db.getConnection();
		em.getTransaction().begin();
		Account caa=(Account) em.find(Account.class,new Long(accNo));
		em.getTransaction().commit();
		return caa.getTran();
	}

	
	
}
